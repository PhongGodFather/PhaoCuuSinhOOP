#include "MusicPlayer.h"
MusicPlayer::~MusicPlayer()
{
	delete user;
	for (auto i : songList)
		delete i;
	songList.clear();
}
bool isAccountExist(string temp)
{
	fstream file("Accounts/" + temp + ".txt", ios::in);
	if (file.fail())
	{
		file.close();
		return false;
	}
	file.close();
	return true;
}
void MusicPlayer::userLogin()
{
	string space;
	int n;
	cout << "1.Dang nhap\n2.Dang ky\n";
	cin >> n;
	getline(cin, space);
	if (n == 1)
	{
		string username, password;
		cout << "Nhap vao username: ";
		getline(cin, username);
		while (!isAccountExist(username))
		{
			cout << "Tai khoan khong ton tai !\n";
			cout << "Nhap vao username: ";
			getline(cin, username);
		}
		fstream file("Accounts/" + username + ".txt", ios::in);
		string truePass;
		file >> truePass;
		cout << "Nhap vao password: ";
		getline(cin, password);
		while (password != truePass)
		{
			cout << "Sai mat khau vui long nhap lai: ";
			getline(cin, password);
		}

		file >> space;
		if (space == "VIP")
		{
			VIP_Account* temp = new VIP_Account();
			temp->username = username;
			temp->password = password;
			file >> temp->money >> temp->expiredMonths >> temp->curMonth;
			user = temp;
		}
		else
		{
			user = new Account();
			user->username = username;
			user->password = password;
			file >> user->money;
		}
		file.close();
	}
	else
	{
		cout << "1.Tai khoan thuong\n2.Tai khoan VIP\n";
		cin >> n;
		getline(cin, space);
		if (n == 1)
		{
			user = new Account();
			cin >> user;
		}
		else
		{
			user = new VIP_Account();
			cin >> user;
		}
	}
}
void Account::behavior(int price)
{
	money -= price;
}
void VIP_Account::behavior(int price)
{
	money -= price / 2;
}
bool valid(string temp, int type = 1)
{
	if (type != 1)
		if (temp.size() < 8)
			return false;
	for (int i = 0; i < temp.size(); i++)
		if (temp[i] == ' ')
			return false;
	return true;
}
istream& operator>>(istream& in, Account*& account)
{
	cout << "Nhap username (yeu cau khong co dau cach): ";
	getline(in, account->username);
	while (!valid(account->username))
	{
		cout << "username khong hop le \n";
		cout << "Nhap username: ";
		getline(in, account->username);
	}
	cout << "Nhap password (it nhat 8 ki tu, khong dau cach): ";
	getline(in, account->password);
	while (!valid(account->password, 2))
	{
		cout << "password khong hop le \n";
		cout << "Nhap username: ";
		getline(in, account->password);
	}
	account->input(); // override optional things
	return in;
}
void VIP_Account::input()
{
	cout << "Goi cuoc tai khoan VIP la 200.000vnd/thang \n";
	expiredMonths = 2;
	curMonth = 0;
	money = 300000; // default for VIP account
}
void VIP_Account::extendService()
{
	unsigned int inputMoney;
	cout << "Nhap so tien cho tai khoan VIP:\n";
	cin >> inputMoney;
	money += inputMoney;

	while ((money / 200000) < 1)
	{
		cout << "Khong du tien de gia han, Vui long nap them: ";
		cin >> inputMoney;
		money += inputMoney;
	}
	cout << "Ban gia han duoc " << money / 200000 << " thang\n";
	money -= money / 200000;
	curMonth = 0;
}
void VIP_Account::output()
{
	cout << "Tai khoan VIP con " << expiredMonths - curMonth << " thang nua la het han" << endl;
}
ostream& operator<<(ostream& out, Account* temp)
{
	out << "Username: " << temp->username << " ,password: " << temp->password << endl;
	out << "Money: " << temp->money << endl;
	temp->output();
	return out;
}
Account::~Account()
{
	/*for (auto i : playlist)
		delete i;
	playlist.clear();*/
}
istream& operator>>(istream& in, Song*& temp)
{
	cout << "Ten bai hat: ";
	getline(in, temp->name);
	cout << "Ten ca si: ";
	getline(in, temp->singer);
	cout << "The loai: \n1.Viet Nam\n2.Au My\n3.Han Quoc\n";
	int n;
	in >> n;
	if (n == 1) temp->type = "Viet Nam";
	else if (n == 2) temp->type = "Au My";
	else temp->type = "Han Quoc";
	cout << "Nam san xuat: ";
	in >> temp->year_produce;
	cout << "Luot nghe hien tai: ";
	in >> temp->luotNghe;
	temp->input(); // override things
	cout << "==Bat dau nhap vao lyric cho bai hat==\n";
	string lyric;
	while (true)
	{
		cout << "Tiep tuc nhap loi bai hat ? (y/n): ";
		char k;
		cin >> k;
		if (k == 'y' || k == 'Y')
		{
			getline(cin, lyric);
			cout << "Dong thu " << temp->lyric.size() + 1 << " : ";
			getline(cin, lyric);
			temp->lyric.push_back(lyric);
		}
		else
			break;
	}
	return in;
}
ostream& operator<<(ostream& out, Song* temp)
{
	out << "Bai hat: " << temp->name << " , Singer: " << temp->singer << " , The loai: " << temp->type << endl;
	out << "Nam san xuat: " << temp->year_produce << ", Luot nghe: " << temp->luotNghe << endl;
	temp->output();
	return out;
}
void CopyrightSong::input()
{
	cout << "So tien cho ban quyen: ";
	cin >> price;
}
void CopyrightSong::output()
{
	cout << "Gia tri ban quyen: " << price << " vnd\n";
}
void MusicPlayer::addNewSong()
{
	cout << "1.Normal Song\n2.Copyright Song\n";
	int n;
	cin >> n;
	string space;
	getline(cin, space);
	if (n == 1)
	{
		Song* s = new Song();
		cin >> s;
		songList.push_back(s);
	}
	else
	{
		Song *s = new CopyrightSong();
		cin >> s;
		songList.push_back(s);
	}
	cout << "Successfully added new song\n";
}
bool MusicPlayer::loadFile(string name)
{
	fstream file("MusicWeb/" + name + ".txt", ios::in);
	if (file.fail())
	{
		file.close();
		return false;
	}
	string temp;
	file >> temp;
	Song* song;
	if (temp == "Copyright")
	{
		song = new CopyrightSong();
		file >> song->price;
	}
	else
	{
		song = new Song();
		song->price = 0;
	}
	song->name = name;
	getline(file, temp, '\n');
	song->singer = temp;
	file >> song->year_produce >> song->luotNghe;
	getline(file, temp, '\n');
	temp.erase(0, 1);
	song->type = temp;
	while (!file.eof())
	{
		getline(file, temp, '\n');
		song->lyric.push_back(temp);
	}
	songList.push_back(song);
	file.close();
	return true;
}
MusicPlayer::MusicPlayer()
{
	fstream file("MusicWeb/MusicWebSongList.txt", ios::in);
	while (!file.eof())
	{
		string temp;
		getline(file, temp, '\n');
		loadFile(temp);
	}
	file.close();
}
void MusicPlayer::top5Songs()
{
	for (int i = 0; i < songList.size(); i++)
		for (int j = i + 1; j < songList.size(); j++)
			if (songList[j]->luotNghe > songList[i]->luotNghe)
				swap(songList[i], songList[j]);
	int size = 5;
	if (songList.size() < 5)
		size = songList.size();
	for (int i = 0; i < size; i++)
		cout << "Name: " << songList[i]->name << " ,luot nghe: " << songList[i]->luotNghe << " ,type:" << songList[i]->type << endl;
}
bool sameString(string A, string B)
{
	if (A.size() != B.size())
	{
		cout << "not same size";
		return false;
	}
	for (int i = 0; i < A.size(); i++)
		if (A[i] != B[i])
			return false;
	return true;
}
void MusicPlayer::listTypeSong()
{
	string _type;
	cout << "The loai: \n1.Viet Nam\n2.Au My\n3.Han Quoc\n";
	int n;
	cin >> n;
	if (n == 1) _type = "Viet Nam";
	else if (n == 2) _type = "Au My";
	else _type = "Han Quoc";
	
	for (auto i : songList)
	{
		if (i->type == _type)
			cout << i << endl;
	}
}
bool MusicPlayer::SongExist(string name)
{
	for (auto i : songList)
		if (name == i->name)
			return true;
	return false;
}
void MusicPlayer::playSong(string name)
{
	if (!SongExist(name))
	{
		cout << "Bai hat khong ton tai !\n";
		return;
	}
	for (auto i : songList)
	{
		if (i->name == name)
		{
			if (user->money - i->price < 0 && !user->isVIP() || user->money - i->price / 2 < 0 && user->isVIP())
			{
				cout << "Ban khong co du tien de nghe bai hat nay!\n";
				break;
			}
			user->behavior(i->price);
			for (auto j : i->lyric)
			{
				cout << j << endl;
				Sleep(100);
			}
			break;
		}
	}
}
void MusicPlayer::playPlaylist()
{
	if (user->playlist.empty())
	{
		cout << "Danh sach playlist is empty\n";
		return;
	}
	for (auto i : user->playlist)
	{
		cout << i << endl;
		for (auto j : i->lyric)
		{
			cout << j << endl;
			Sleep(100);
		}
	}
}
void MusicPlayer::printAllSongs()
{
	for (int i = 0; i < songList.size(); i++)
		cout << i + 1 << "." << songList[i] << endl;
}
void MusicPlayer::napTien()
{
	cout << "Nhap so tien ma ban can nap: ";
	int n;
	cin >> n;
	user->money += n;
}
void MusicPlayer::addToPlaylist()
{
	cout << "Nhap vao ten bai hat ban muon them: ";
	string temp;
	getline(cin, temp);
	if (!SongExist(temp))
	{
		cout << "Bai hat tren khong ton tai \n";
		return;
	}
	for (auto i : songList)
	{
		if (i->name == temp)
		{
			if (user->money - i->price < 0 && !user->isVIP() || user->money - i->price / 2 < 0 && user->isVIP())
			{
				cout << "Ban khong co du tien de nghe bai hat nay!\n";
				return;
			}
			user->behavior(i->price);
			break;
		}
	}
	for (auto i : songList)
		if (i->name == temp)
			user->playlist.push_back(i);
	cout << "Danh sach playlist cua ban:\n";
	for (auto i : user->playlist)
		cout << i->name << endl;
}
void VIP_Account::writeOut()
{
	fstream file("Accounts/" + username + ".txt", ios::app);
	file << " " << expiredMonths << " " << curMonth;
	file.close();
}
void MusicPlayer::writeFile()
{
	fstream file("Accounts/" + user->username + ".txt", ios::out);
	file << user->password << " ";
	if (user->isVIP()) file << "VIP";
	else file << "Normal";
	file << " " << user->money;
	file.close();
	user->writeOut(); // override
}
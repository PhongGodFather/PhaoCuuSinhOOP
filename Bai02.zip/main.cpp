﻿#include "MusicPlayer.h"
#include <iostream>	
using namespace std;
void main()
{
    MusicPlayer music;
    music.userLogin();
    system("cls");
    while (true)
    {
        cout << "1.List musics with type\n2.Top 5 songs \n3.Play Song\n4.Add new Song\n5.Account info\n6.Nap tien vao tai khoan\n7.Danh sach bai hat hien tai\n";
        cout << "8.Them vao playlist\n9.Play playlist\n10.Exit\n";
        int n;
        cin >> n;
        if (n == 1)
        {
            system("cls");
            music.listTypeSong();
        }
        else if (n == 2)
        {
            system("cls");
            music.top5Songs();
        }
        else if (n == 3)
        {
            system("cls");
            string songname;
            getline(cin, songname);
            cout << "Nhap vao ten bai hat ma ban muon chon: ";
            getline(cin, songname);
            if (!music.SongExist(songname))
                cout << "Ten bai hat khong ton tai !\n";
            else
                music.playSong(songname);
        }
        else if (n == 4)
        {
            system("cls");
            music.addNewSong();
        }
        else if (n == 5)
        {
            system("cls");
            music.printAccountInfo();
        }
        else if (n == 6)
        {
            system("cls");
            music.napTien();
        }
        else if (n == 7)
        {
            system("cls");
            music.printAllSongs();
        }
        else if (n == 8)
        {
            system("cls");
            string temp;
            getline(cin, temp); // avoid blank enter
            music.addToPlaylist();
        }
        else if (n == 9)
        {
            system("cls");
            music.playPlaylist();
        }
        else if (n == 10)
            break;
    }
    music.writeFile();
}
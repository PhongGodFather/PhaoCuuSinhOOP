#pragma once
#ifndef _MUSIC_PLAYER
#define _MUSIC_PLAYER
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <Windows.h>
using namespace std;
class Song
{
protected:
	string name, singer, type;
	unsigned int year_produce, luotNghe;
	int price;
	vector<string> lyric;
public:
	virtual void input() { };
	virtual void output() { };
	friend istream& operator>>(istream&, Song*&);
	friend ostream& operator<<(ostream&, Song*);

	friend class MusicPlayer;
};

class CopyrightSong : public Song
{
public:
	void input();
	void output();
};

class Account
{
protected:
	int money;
	string username, password;
	vector<Song*> playlist;
public:

	~Account();
	virtual void input() 
	{ 
		money = 100000; // default for normal account
	}
	virtual void output() { };
	virtual bool isVIP() { return false; }
	virtual void behavior(int);
	virtual void writeOut() { }
	friend istream& operator>>(istream&, Account*&);
	friend ostream& operator<<(ostream&, Account*);
	friend class MusicPlayer;
};
istream& operator>>(istream&, Account*&);
ostream& operator<<(ostream&, Account*);

class VIP_Account : public Account
{
	unsigned int expiredMonths, curMonth;
public:
	void behavior(int);
	bool isVIP() { return true; }
	bool isExpired() { return (curMonth == expiredMonths); }
	void extendService();
	void input();
	void output();
	void writeOut();
	friend class MusicPlayer;
};

class MusicPlayer
{
	Account* user;
	vector<Song*> songList; // list of song that we have
public:
	void writeFile();
	bool loadFile(string);
	MusicPlayer();
	void userLogin();
	void playSong();
	void addNewSong();
	void top5Songs();
	void listTypeSong();
	void printAllSongs();
	void playSong(string name);
	bool SongExist(string name);
	void printAccountInfo() { cout << user; }
	void napTien();
	void addToPlaylist();
	void playPlaylist();
	~MusicPlayer();
	friend istream& operator>>(istream&, MusicPlayer&); // addSong
	friend ostream& operator<<(ostream&, MusicPlayer); // outsong maybe
};
istream& operator>>(istream&, MusicPlayer&);
ostream& operator<<(ostream&, MusicPlayer);
#endif // !_MUSIC_PLAYER